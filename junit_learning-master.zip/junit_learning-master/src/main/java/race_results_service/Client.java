package race_results_service;

public interface Client {
    void receive(Message message);
}
