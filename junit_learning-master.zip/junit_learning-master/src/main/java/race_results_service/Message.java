package race_results_service;

public interface Message {
}
